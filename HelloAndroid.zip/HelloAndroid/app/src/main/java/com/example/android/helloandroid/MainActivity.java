package com.example.android.helloandroid;

/**
 * Created by alek on 21/11/2017.
 */



        import android.content.Intent;
        import android.net.Uri;
        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.text.method.LinkMovementMethod;
        import android.view.View;
        import android.widget.TextView;


/**
 * This app displays an order form to order coffee.
 */
public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
public void goWebsite (View view) {
        Intent browserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.udacity.com"));
        startActivity(browserIntent);

}
    public void udacity (View view) {
        Intent browserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.udacity.com"));
        startActivity(browserIntent);

    }

}